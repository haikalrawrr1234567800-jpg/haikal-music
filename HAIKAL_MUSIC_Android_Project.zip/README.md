# HAIKAL MUSIC

An Android Studio starter project for an offline music player with a Spotify-inspired dark interface and neon-blue accents.

## Features
- Import one or multiple audio files using Android's document picker.
- Persist access to selected files where the document provider supports it.
- Offline playback using AndroidX Media3 ExoPlayer.
- Background playback and lock-screen/media notification controls through MediaSessionService.
- Local playlist saved on the device.

## Build
1. Install Android Studio (a recent version) and Android SDK 35.
2. Open this folder in Android Studio.
3. Let Gradle sync, then run the `app` configuration on an Android device (Android 7.0+).
4. Use **ADD SONGS** to select MP3/audio files stored on your phone.

The project source is provided; it has not been compiled or tested on a physical device in this environment.
