package com.haikal.music

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executor
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout
    private lateinit var songsBox: LinearLayout
    private lateinit var nowPlaying: TextView
    private lateinit var playButton: Button
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var player: MediaController? = null
    private val songs = mutableListOf<Song>()

    data class Song(val uri: Uri, val title: String)

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        uris.forEach { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) { }
            if (songs.none { it.uri == uri }) songs.add(Song(uri, displayName(uri)))
        }
        saveSongs()
        renderSongs()
        Toast.makeText(this, "${uris.size} lagu ditambah", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadSongs()
        renderSongs()
        connectController()
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                player = controllerFuture?.get()
                player?.addListener(object : Player.Listener {
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = updateNowPlaying()
                    override fun onIsPlayingChanged(isPlaying: Boolean) = updatePlayButton()
                    override fun onPlaybackStateChanged(playbackState: Int) = updateNowPlaying()
                })
                updateNowPlaying()
                updatePlayButton()
            } catch (_: Exception) {
                Toast.makeText(this, "Pemain muzik gagal dimulakan", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(20))
            setBackgroundColor(0xFF080D18.toInt())
        }
        val header = TextView(this).apply {
            text = "HAIKAL MUSIC"
            textSize = 27f
            setTextColor(0xFF42B6FF.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(header)
        root.addView(TextView(this).apply {
            text = "YOUR MUSIC. YOUR WORLD. PLAY OFFLINE."
            textSize = 10f
            letterSpacing = 0.12f
            setTextColor(0xFF8293AA.toInt())
            setPadding(0, dp(4), 0, dp(22))
        })
        val section = TextView(this).apply {
            text = "YOUR LIBRARY"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(section)
        val add = Button(this).apply {
            text = "+  ADD SONGS"
            setTextColor(0xFF06111D.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF42B6FF.toInt()))
            setOnClickListener { picker.launch(arrayOf("audio/mpeg", "audio/*")) }
        }
        root.addView(add, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(12); bottomMargin = dp(12) })
        songsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(songsBox, LinearLayout.LayoutParams(-1, 0, 1f))
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(0xFF111D30.toInt())
        }
        nowPlaying = TextView(this).apply {
            text = "NOTHING PLAYING"
            textSize = 12f
            setTextColor(0xFF42B6FF.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        panel.addView(nowPlaying)
        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        controls.addView(control("⏮") { player?.seekToPreviousMediaItem() })
        playButton = control("▶") { togglePlayback() }
        controls.addView(playButton)
        controls.addView(control("⏭") { player?.seekToNextMediaItem() })
        panel.addView(controls)
        root.addView(panel)
        setContentView(root)
    }

    private fun control(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 20f
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF1D3553.toInt()))
        setOnClickListener { action() }
    }

    private fun togglePlayback() {
        val p = player ?: return
        if (p.isPlaying) p.pause() else {
            if (p.mediaItemCount == 0 && songs.isNotEmpty()) playSong(0) else p.play()
        }
        updatePlayButton()
    }

    private fun playSong(index: Int) {
        val p = player ?: run {
            Toast.makeText(this, "Pemain sedang disediakan, cuba lagi sekejap", Toast.LENGTH_SHORT).show()
            return
        }
        val items = songs.map { MediaItem.Builder().setUri(it.uri).setMediaMetadata(
            androidx.media3.common.MediaMetadata.Builder().setTitle(it.title).build()
        ).build() }
        p.setMediaItems(items, index, 0L)
        p.prepare()
        p.play()
        updateNowPlaying()
    }

    private fun renderSongs() {
        if (!::songsBox.isInitialized) return
        songsBox.removeAllViews()
        if (songs.isEmpty()) {
            songsBox.addView(TextView(this).apply {
                text = "Your library is waiting.\nTap ADD SONGS to import MP3 files."
                textSize = 14f
                setTextColor(0xFF8293AA.toInt())
                setPadding(0, dp(30), 0, dp(10))
            })
        } else songs.forEachIndexed { index, song ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(8), dp(8), dp(8))
                setBackgroundColor(if (index % 2 == 0) 0xFF101A2A.toInt() else 0xFF0B1422.toInt())
                setOnClickListener { playSong(index) }
            }
            val icon = TextView(this).apply {
                text = "♫"
                textSize = 22f
                setTextColor(0xFF42B6FF.toInt())
                setPadding(0, 0, dp(12), 0)
            }
            val title = TextView(this).apply {
                text = song.title
                textSize = 14f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(0xFFFFFFFF.toInt())
            }
            row.addView(icon)
            row.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
            songsBox.addView(row)
            val divider = View(this).apply { setBackgroundColor(0xFF1B2B42.toInt()) }
            songsBox.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    private fun displayName(uri: Uri): String {
        var name = "Unknown track"
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0) ?: name
        }
        return name
    }

    private fun saveSongs() {
        val array = JSONArray()
        songs.forEach { array.put(JSONObject().put("uri", it.uri.toString()).put("title", it.title)) }
        getSharedPreferences("library", MODE_PRIVATE).edit().putString("songs", array.toString()).apply()
    }

    private fun loadSongs() {
        val raw = getSharedPreferences("library", MODE_PRIVATE).getString("songs", "[]") ?: "[]"
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val uri = Uri.parse(item.getString("uri"))
                songs.add(Song(uri, item.getString("title")))
            }
        } catch (_: Exception) { songs.clear() }
    }

    private fun updateNowPlaying() {
        val p = player ?: return
        nowPlaying.text = p.currentMediaItem?.mediaMetadata?.title?.toString() ?: "NOTHING PLAYING"
        updatePlayButton()
    }

    private fun updatePlayButton() {
        if (::playButton.isInitialized) playButton.text = if (player?.isPlaying == true) "⏸" else "▶"
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        player = null
        super.onDestroy()
    }
}
